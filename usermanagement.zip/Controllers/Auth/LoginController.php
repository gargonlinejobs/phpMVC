<?php

	class LoginController extends Controller {

		public static function CreateView() {
			$ds = DIRECTORY_SEPARATOR;
            $LoginView = realpath(dirname(__FILE__)  . $ds . '..'. $ds . '..') . $ds . "Views" . $ds . "Auth" . $ds . "Login" . $ds . "Login.php";
			require_once($LoginView);
		}

		public static function authenticate() {
		}

	}
	/*namespace Db\Auth;
	
	use Utils\clsUtils;
	use config;

	class LoginDb {
		
		private $stmt;
		private $email;
		private $password;
		private $clsUtils;
		private $connection;
		
		public function __construct($email, $password) {
			$this->email = $email;
			$this->password = $password;
			$this->clsUtils = new clsUtils();
			$this->connection = (new config())->connect();
		}
		
		public function authenticate() {
			$query = "Select user_id, is_active from tbluser where email = ? and password = ?";
			$this->stmt = $this->connection->prepare($query);
			$this->stmt->bind_param("ss", $this->email, $this->password);
			$this->stmt->execute();
			
			$result = $this->stmt->get_result();
			if($result->num_rows > 0) {
				$row = $result->fetch_array(MYSQLI_ASSOC);
				return [
					"user_id" => $row["user_id"],
					"is_active" => $this->clsUtils->toBool($row["is_active"])
				];
			}
			return null;
		}
	}*/
?>