<?php
	class Routes {
		
		public static $appRoutes = [];

		public static function set($routeName, $function) {
			self::$appRoutes[] = $routeName; 
			if($_GET["url"] == $routeName) {
				$function->__invoke();
			}
		}
	}
?>