<?php
	
	class config {
		
		private $server = "localhost";
		private $username = "root";
		private $password = "";
		private $databaseName = "jqueryphp";

		const domainPart = 'http://192.168.1.3:1234/My/learning/php/usermanagement/';
		const requestUri = "/My/learning/php/usermanagement/";
		const imagesFolder = "assts/images/";

		public function connect() {
			$connection = mysqli_connect($this->server, $this->username, $this->password, $this->databaseName);		
			if (mysqli_connect_errno())
			{
				echo "Failed to connect to MySQL: " . mysqli_connect_error();
				die();
			}
			return $connection;
		}
	}
	
	
	//$admindomainpart = 'http://192.168.1.2:1234/My/learning/php/usermanagement/';
?>