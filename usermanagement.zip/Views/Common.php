<script>
    var processingImageUrl = '<img id="imgProcessing" src="<?php echo config::domainPart . config::imagesFolder . 'ajax-loader.gif'?>" />';
 
    function SetHeaderMessage(isError, Message, ID ) {
        $("." + ID).removeClass("alert-danger").removeClass("alert-success").removeClass("alert");
        if(Message === "") {
            $("." + ID).html("").hide();
            return;
        }
        var className = "alert-success alert";
        if(isError) {
            className = "alert-danger alert";
        }
        $("." + ID).addClass(className).html(Message).show();
    }

</script>