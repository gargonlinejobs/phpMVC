<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">        
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
        <title>Login</title>        
    </head>
    <body>
        <style>
            body {
                padding-top: 3rem;
            }
            .pre-formatted {
                white-space: pre;
            }
        </style>
        
        <div id="app">
            <?php 
                $ds = DIRECTORY_SEPARATOR;
                $topNav = realpath(dirname(__FILE__)  . $ds . '..' . $ds . "..") . $ds . "Partials" . $ds . "TopNav.php";
                include($topNav);
            ?>
            <div class="container-fluid">
                <div class="row justify-content-center">
                    <div class="col-md-4">
						<main class="py-4">
							<div class="card">
								<h4 class="card-header">Login</h4>
								<div class="card-body">
									<div class="alert headerMessage alert-dismissable" style="display: none;"></div>
									<form id="loginForm">
										<div class="col-sm-12 col-md-12">
											<div class="form-group">
												<label for="email" class="control-label">UserName or E-Mail Address</label>
												<input type="text" name="email" class="form-control">
											</div>
										</div>

										<div class="col-sm-12 col-md-12">
											<div class="form-group">
												<label for="password" class="control-label">Password</label>
												<input type="password" name="password" autocomplete="off" class="form-control">
											</div>
										</div>
										
										<div class="col-sm-12 col-md-12">
											<div class="form-group">
                                                <button class="btn btn-primary">Log In</button>
												<a class="btn btn-link" title="Forgot Password" href="">Forgot Password</a>
											</div>
										</div>
									</form>
								</div>
							</div>
						</main>
					</div>
                </div>
            </div>
        </div>
        <script src="https://code.jquery.com/jquery-3.2.1.min.js" ></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>        
		<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/jquery.validate.js"></script>
        <?php 
            $ds = DIRECTORY_SEPARATOR;
            $Common = realpath(dirname(__FILE__)  . $ds . '..' . $ds . "..") . $ds . "Common.php";
            include($Common);
        ?>
        <?php include('Js/LoginJs.php') ?>
    </body>
</html>