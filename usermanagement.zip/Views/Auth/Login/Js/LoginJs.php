<script>
	$(document).ready(function() {
		$("form#loginForm").submit(function(e) {
            e.preventDefault();
        }).validate({
            rules: {
                email: {
                    required: true
                },
                password: {
                    required: true
                }
            }, 
            messages: {
            },
            submitHandler: function(form) {

                var data = {
                    "email": $("input[name='email']").val(), 
                    "password": $("input[name='password']").val()
                };
                $.ajax({
                    method: "POST",
                    url: "<?php echo (config::domainPart . "apiAuthenticateUser"); ?>",
                    cache: false,
                    async: true,
                    data: JSON.stringify(data),
                    contentType: "application/json; charset=utf-8",
                    beforeSend: function(xhr, opts) {
                        debugger;
                        $(form).find(":submit").hide().after(processingImageUrl);
                        SetHeaderMessage(true, "", "headerMessage");
                    },
                    success: function(response) {
                        SetHeaderMessage(!response.Status, response.message, "headerMessage");
                        if(response.Status) {
                            if(response.Data === null) {
                                location.href = "";
                            }
                        }
                        else {
                            $(form).find("#imgProcessing").remove();
                        }
                    },
                    error: function(error) {
                        var errorData = error.responseJSON.errors;
                        if(errorData !== null && typeof errorData !== "undefined") {
                            var message = "";
                            $.each(errorData, function(index, error) {
                                message = message + error[0] + "\n";
                            });
                            SetHeaderMessage(true, message, "headerMessage");
                        }
                        else {
                            SetHeaderMessage(true, error.responseJSON.message, "headerMessage");
                        }
                        $(form).find(":submit").show();
                        $(form).find("#imgProcessing").remove();
                            
                    },
                    complete: function() {
                    }
                });
            }
        });
	});
</script>