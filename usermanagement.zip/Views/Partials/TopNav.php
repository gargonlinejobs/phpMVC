<header>
	<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
		<a class="navbar-brand" href="#">Pankaj</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>

		<div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav mr-auto">
				
			</ul>
			
			<ul class="navbar-nav">           
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						UserName
					</a>
					<div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
						<a class="dropdown-item" href="">Edit Profile</a>
						<div class="dropdown-divider"></div>
						<a class="dropdown-item" href="#">Logout</a>
						
					</div>
				</li>
			</ul>
		
			<ul class="navbar-nav">           
				<li class="nav-item">
					<a class="nav-link" href="">Login</a>
				</li>
			</ul>
			
		</div>
	</nav>
</header>