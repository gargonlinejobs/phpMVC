<?php

namespace Utils;

class clsUtils {
    
	public function toBool($var) {
        switch (strtolower($var)) {
            case '1':
            case 'true':
            case 'on':
            case 'yes':
            case 'y':
                return true;
            default:
                return false;
        }
    }
	
}
