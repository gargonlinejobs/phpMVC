<?php

	namespace Logic\Auth;
	
	use Db\Auth\LoginDb;
	
	class LoginModel {
		
		private $email;
		private $password;
		
		public function __construct($email, $password) {
			$this->email = $email;
			$this->password = md5($password);
		}

		public function authenticate() {
			$LoginDb = new LoginDb($this->email, $this->password);
			$result = $LoginDb->authenticate();
			print_r($result);
			if($result == null) {
				$data = [
					"status" => false,
					"message" => "Invalid credentials"
				];
			}
			else if(!$result["is_active"]) {
				$data = [
					"status" => false,
					"message" => "Your account is not active"
				];
			}
			else {
				$data = [
					"status" => false,
					"message" => "Login successful"
				];
			}
			
			return $data;
		}
	}
?>