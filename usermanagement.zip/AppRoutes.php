<?php 
	function my_autoloader($class) {
		include_once 'Routes.php';
		include_once 'config.php';
		include_once 'Controllers/Controller.php';
	}
	spl_autoload_register('my_autoloader');

	Routes::set("login", function() {
		include_once 'Controllers/Auth/LoginController.php';
		LoginController::CreateView();
	});

	Routes::set("apiAuthenticateUser", function() {
		include_once 'Controllers/Auth/LoginController.php';
		die("Hello");
	});
?>